def flame():
    print("Hello, World\n")